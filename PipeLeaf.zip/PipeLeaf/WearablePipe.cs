﻿using System;
using System.Text;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace PipeLeaf
{
    public class WearablePipe : ItemWearable
    {
        const string AttrPipe = "pipeContents";
        const string AttrLoad = "stack";
        const int MaxCapacity = 3;

        // --------- Attribute helpers ---------

        private ItemStack GetLoaded(ItemStack pipeStack, ICoreAPI api)
        {
            var tree = pipeStack.Attributes.GetTreeAttribute(AttrPipe);
            var load = tree?.GetItemstack(AttrLoad);
            load?.ResolveBlockOrItem(api.World);
            return load;
        }

        private void SetLoaded(ItemStack pipeStack, ItemStack toSet)
        {
            var tree = pipeStack.Attributes.GetOrAddTreeAttribute(AttrPipe);
            if (toSet == null) tree.RemoveAttribute(AttrLoad);
            else tree.SetItemstack(AttrLoad, toSet);
        }

        /// <summary>Returns 0–3 without needing ICoreAPI (for naming).</summary>
        private int GetLoadCountFast(ItemStack pipeStack)
        {
            var tree = pipeStack.Attributes.GetTreeAttribute(AttrPipe);
            var load = tree?.GetItemstack(AttrLoad);
            return load?.StackSize ?? 0;
        }

        public int GetLoadCount(ItemStack pipeStack, ICoreAPI api)
        {
            return GetLoaded(pipeStack, api)?.StackSize ?? 0;
        }

        // --------- Loading: up to 3 items total ---------

        /// <summary>
        /// Try to load smokable items from a source slot into the pipe (up to 3).
        /// Pass in the pipeSlot so we can MarkDirty() for sync.
        /// </summary>
        public bool TryLoadFrom(ItemSlot source, ItemSlot pipeSlot, ICoreAPI api, out string failCode)
        {
            failCode = null;

            if (source.Empty)
            {
                failCode = "emptysource";
                return false;
            }

            if (!(source.Itemstack?.Item is SmokableItem))
            {
                failCode = "notsmokable";
                return false;
            }

            var pipeStack = pipeSlot.Itemstack;
            var load = GetLoaded(pipeStack, api);

            // 🚫 Rule: only load if completely empty
            if (load != null && load.StackSize > 0)
            {
                failCode = "notempty";
                return false;
            }

            int toTake = GameMath.Clamp(source.Itemstack.StackSize, 0, MaxCapacity);
            if (toTake <= 0)
            {
                failCode = "nothingtaken";
                return false;
            }

            var taken = source.TakeOut(toTake);   // returns ItemStack
            source.MarkDirty();

            if (taken == null || taken.StackSize <= 0)
            {
                failCode = "nothingtaken";
                return false;
            }

            taken.StackSize = GameMath.Clamp(taken.StackSize, 0, MaxCapacity);
            SetLoaded(pipeStack, taken);
            pipeSlot.MarkDirty();
            return true;
        }

        // --------- Smoking: consume 1 per successful inhale ---------

        public bool TrySmoke(IWorldAccessor world, EntityPlayer player, ItemStack pipeStack, out string failCode)
        {
            failCode = null;

            var load = GetLoaded(pipeStack, world.Api);
            if (load == null || load.StackSize <= 0) { failCode = "pipeempty"; return false; }
            if (!(load.Item is SmokableItem smokable)) { failCode = "notsmokable"; return false; }

            // Let the smokable apply its effects (your SmokableItem exposes Smoke(world, entity))
            smokable.Smoke(world, player);

            // Consume one unit
            load.StackSize--;
            if (load.StackSize <= 0) load = null;
            SetLoaded(pipeStack, load);
            MarkEquippedPipeSlotDirty(player, pipeStack, world);

            // Feedback
            world.PlaySoundAt(new AssetLocation("sounds/effect/embers"), player, null);
            SpawnExhaleParticles(world, player);

            // Mark the equipped slot dirty so attributes sync
            MarkEquippedPipeSlotDirty(player, pipeStack, world);
            return true;
        }

        private void MarkEquippedPipeSlotDirty(EntityPlayer entityPlayer, ItemStack pipeStack, IWorldAccessor world)
        {
            var owningPlayer = world.PlayerByUid(entityPlayer.PlayerUID);
            if (owningPlayer == null) return;

            var wearInv = owningPlayer.InventoryManager.GetOwnInventory(GlobalConstants.characterInvClassName);
            if (wearInv == null) return;

            for (int i = 0; i < wearInv.Count; i++)
            {
                var slot = wearInv[i];
                if (!slot.Empty && ReferenceEquals(slot.Itemstack, pipeStack))
                {
                    slot.MarkDirty();
                    return;
                }
            }
        }

        // --------- Particles ---------

        public void SpawnInhaleParticles(IWorldAccessor world, Entity entity)
        {
            var pos = entity.SidedPos;

            // Forward vector from head yaw/pitch
            var fwd = new Vec3f(
                (float)(-Math.Sin(pos.Yaw) * Math.Cos(pos.Pitch)),
                (float)(-Math.Sin(pos.Pitch)),
                (float)(Math.Cos(pos.Yaw) * Math.Cos(pos.Pitch))
            );

            // Spawn a bit further out to avoid immediate collision with the face
            var mouth = pos.XYZ.AddCopy(entity.LocalEyePos).AddCopy(fwd * 0.35f);

            // Larger, more transparent quads
            var smokeHeld = new SimpleParticleProperties(
                2, 3,  // spawn a few each tick
                ColorUtil.ToRgba(40, 122, 139, 174),
                mouth, mouth,
                new Vec3f(-0.02f, 0.02f, -0.02f),
                new Vec3f(0.02f, 0.05f, 0.02f),
                2.5f, 0f,    // life length up to 2.5s
                0.25f, 0.45f,
                EnumParticleModel.Quad
            );

            smokeHeld.SelfPropelled = true;            // keep moving through collisions
            smokeHeld.WindAffected = true;            // let wind influence gently
            smokeHeld.GravityEffect = -0.01f;          // slight lift
            smokeHeld.AddPos.Set(0.06, 0.03, 0.06);    // tiny random spawn jitter

            // Soft fade-out and a hint of growth while traveling forward
            smokeHeld.OpacityEvolve = new EvolvingNatFloat(EnumTransformFunction.LINEAR, -220f);
            smokeHeld.SizeEvolve = new EvolvingNatFloat(EnumTransformFunction.LINEAR, 0.08f);

            world.SpawnParticles(smokeHeld);
        }



        public static void SpawnExhaleParticles(IWorldAccessor world, Entity entity)
        {
            var pos = entity.SidedPos;

            var fwd = new Vec3f(
                (float)(-Math.Sin(pos.Yaw) * Math.Cos(pos.Pitch)),
                (float)(-Math.Sin(pos.Pitch)),
                (float)(Math.Cos(pos.Yaw) * Math.Cos(pos.Pitch))
            );

            var mouth = pos.XYZ.AddCopy(entity.LocalEyePos).AddCopy(fwd * 0.25f);

            // Stronger forward push, longer life, bigger size
            var minVel = new Vec3f(fwd.X * 0.08f - 0.01f, fwd.Y * 0.08f + 0.02f, fwd.Z * 0.08f - 0.01f);
            var maxVel = new Vec3f(fwd.X * 0.12f + 0.02f, fwd.Y * 0.12f + 0.06f, fwd.Z * 0.12f + 0.02f);

            var p = new SimpleParticleProperties(
                6, 10,                                       // quantity
                ColorUtil.ToRgba(120, 220, 220, 220),        // a bit denser (alpha=120)
                mouth, mouth,
                minVel, maxVel,
                0.90f, 1.40f,                                // longer life
                0.25f, 0.50f                                  // larger puff
            );

            p.SelfPropelled = true;

            world.SpawnParticles(p);
        }

        // --------- Tooltip + Name ---------

        public override void GetHeldItemInfo(ItemSlot inSlot, StringBuilder dsc, IWorldAccessor world, bool withDebugInfo)
        {
            base.GetHeldItemInfo(inSlot, dsc, world, withDebugInfo);

            var load = GetLoaded(inSlot.Itemstack, world.Api);
            if (load == null || load.StackSize <= 0)
            {
                dsc.AppendLine("Loaded: empty");
            }
            else
            {
                dsc.AppendLine($"Loaded: {load.StackSize}/{MaxCapacity} {load.GetName()}");
            }
        }

        public override string GetHeldItemName(ItemStack itemStack)
        {
            var baseName = base.GetHeldItemName(itemStack);
            int count = GetLoadCountFast(itemStack);
            return $"{baseName} ({count}/{MaxCapacity})";
        }
    }
}
